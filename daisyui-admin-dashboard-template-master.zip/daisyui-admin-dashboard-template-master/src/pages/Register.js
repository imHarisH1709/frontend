import {useState, useRef} from 'react'
import {Link} from 'react-router-dom'
import Register from '../features/user/Register'

function ExternalPage(){


    return(
        <div className="">
                <Register />
        </div>
    )
}

export default ExternalPage